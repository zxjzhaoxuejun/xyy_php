-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- 主机: localhost
-- 生成日期: 2017 年 09 月 27 日 05:32
-- 服务器版本: 5.0.51
-- PHP 版本: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- 数据库: `xyydata`
-- 

-- --------------------------------------------------------

-- 
-- 表的结构 `admin`
-- 

CREATE TABLE `admin` (
  `admin_id` int(8) NOT NULL auto_increment,
  `admin_name` varchar(24) collate utf8_unicode_ci NOT NULL,
  `admin_pass` varchar(24) collate utf8_unicode_ci NOT NULL,
  `show_num` int(5) NOT NULL,
  PRIMARY KEY  (`admin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

-- 
-- 导出表中的数据 `admin`
-- 

INSERT INTO `admin` VALUES (1, 'admin', '123456', 10);

-- --------------------------------------------------------

-- 
-- 表的结构 `message_mode`
-- 

CREATE TABLE `message_mode` (
  `id` int(11) NOT NULL auto_increment,
  `message_name` varchar(20) collate utf8_unicode_ci NOT NULL COMMENT '姓名',
  `message_iphone` int(11) NOT NULL COMMENT '手机',
  `message_email` varchar(50) collate utf8_unicode_ci default NULL COMMENT '邮箱',
  `message_type` varchar(20) collate utf8_unicode_ci NOT NULL COMMENT '建站类型',
  `message_menoy` varchar(20) collate utf8_unicode_ci NOT NULL COMMENT '费用预算',
  `message_remark` text collate utf8_unicode_ci COMMENT '备注',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=82 ;

-- 
-- 导出表中的数据 `message_mode`
-- 

INSERT INTO `message_mode` VALUES (56, '就会放大', 2147483647, '345624137@qq.com', '官网展示型', '5000以内', '大');
INSERT INTO `message_mode` VALUES (78, '接口的方', 2147483647, '345624137@qq.com', '购物商城型', '3万到10万', '家居服哈减肥哈');
INSERT INTO `message_mode` VALUES (71, '点击', 2147483647, '345624137@qq.com', '官网展示型', '10万以上', '确认');
INSERT INTO `message_mode` VALUES (72, '页码', 2147483647, '345624137@qq.com', '分销商城型', '3万到10万', '用户觉得是发放汇率不出现回复大家符合大家V合成向记者V回家准备好姐姐结婚才是自己开发v');
INSERT INTO `message_mode` VALUES (73, '酒店', 2147483647, '345624137@qq.com', '官网展示型', '3万到10万', '奥会计法');
INSERT INTO `message_mode` VALUES (79, '花时间', 2147483647, '345624137@qq.com', '购物商城型', '5000以内', '三国杀');
INSERT INTO `message_mode` VALUES (80, '接口', 2147483647, '345624137@qq.com', '新零售平台型', '10万以上', '觉得是');
INSERT INTO `message_mode` VALUES (76, '卡迪夫', 2147483647, '345624137@qq.com', '分销商城型', '3万到10万', '254');
INSERT INTO `message_mode` VALUES (77, '加咖啡大', 2147483647, '345624137@qq.com', '购物商城型', '3万到10万', '');
INSERT INTO `message_mode` VALUES (81, '离开谁发', 2147483647, '345624137@qq.com', '购物商城型', '3万到10万', '接口规范是的发生法');
